SEARCH Journal of Media and Communication Research
Online ISSN: 2672-7080
© SEARCH Journal 2025
SEARCH 17(2), 2025, 125–139
DOI: 10.58946/search-17.2.P8
https://fslmjournals.taylors.edu.my/search/
Exploring social media fatigue
through WeChat Use: A diary
study among university students in
Liaoning, China
*Jia Puxiu
Taylor’s University, Lakeside Campus, Malaysia
0362521@sd.taylors.edu.my
Normaliza Abd.Rahim
Taylor’s University, Lakeside Campus, Malaysia
Kuala Lumpur University of Science and Technology (KLUST), Malaysia
Nur Haniz Mohd Nor
Taylor’s University, Lakeside Campus, Malaysia
ABSTRACT
As social media becomes increasingly integrated into everyday communication, the issue of social
media fatigue faced by university students is a growing concern. This study empirically examines the
primary types of fatigue associated with WeChat use among university students in Liaoning Province,
China. It explains how these fatigues intersect and evolve in daily use situations. Through convenience
sampling, the study invited 15 university students to participate in a two-week diary study. Thematic
analysis reveal that social media fatigue is primarily manifested as information overload, task-
oriented use fatigue, and privacy fatigue, and these types of fatigue interact with each other, leading
to emotional and behavioural exhaustion, ultimately. Based on the Uses and Gratifications Theory,
the study suggests that the overlay of digital stress exacerbates anxiety, avoidance behaviours, and
communication stress, while privacy concerns related to self-presentation and control of information
enhance users’ concerns about sharing. This study contributes to the understanding of university
students’ challenges in balancing the use of WeChat across their academic, social, and personal
lives, as well as provides empirical evidence and intervention ideas to alleviate social media fatigue
in educational settings to enhance university students’ mental health.
Keywords: WeChat use, social media fatigue, information overload, privacy concerns
* Corresponding author

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
INTRODUCTION
Social media has become an integral part of young people’s daily lives in China, providing
convenience for communication, learning, and entertainment. However, excessive use has
led to a rising phenomenon known as social media fatigue, which refers to users’ tendency
to reduce or withdraw from social media use due to emotional or cognitive overload (Pang,
2021; Zawawi et al., 2025; Zhang et al., 2021). Prior research has identified major causes
including information overload, social pressure, and functional fatigue (Jabeen et al.,
2023; Ou et al., 2023). When users find it difficult to manage overwhelming interactions
and content, they experience negative emotions such as anxiety, disappointment, and
exhaustion (Bhowmik, 2025; Wu et al., 2022).
Although social media fatigue has received scholarly attention, most existing
studies remain at a general descriptive level, with a limited focus on its different types
and how they manifest in users’ daily behaviour. In particular, research rarely explores
the specific fatigue experiences associated with WeChat use among Chinese university
students. To address this gap, this study adopted a two-week diary research method to
explore students’ everyday interactions on WeChat. The aim is to identify and classify
the types of social media fatigue experienced, and to better understand their underlying
mechanisms in the context of higher education.
LITERATURE REVIEW
Social media use in the context of the Uses and Gratifications Theory
The emergence of new media has empowered users with greater freedom to choose online
services based on their individual needs. People now actively create content to satisfy
desires such as self-expression and social connection. The Uses and Gratifications Theory
(UGT) provides a valuable framework for understanding such behaviours, emphasising
users’ motivations for media use, the gratifications they seek, and the satisfaction derived
from these experiences (Cheng, 2022).
Originally developed to explore why audiences actively select specific media, UGT
identifies several core motivations: information-seeking, social interaction, entertainment,
and identity management (Whiting & Williams, 2013). In the context of WeChat usage,
recent research has highlighted three types of gratification that significantly influence
users’ continued engagement: hedonic gratification (perceived enjoyment), utilitarian
gratification (information exchange), and technological gratification (platform usability
and appeal) (Gan et al., 2021; Li et al., 2025; Metwally et al., 2025). Among these, hedonic
gratification appears to play the strongest role, especially through WeChat Moments’ like
and comment functions, which enhance emotional resonance and foster an entertaining
atmosphere (Cheng, 2022). However, the effects of social media use are not uniformly
positive.
While platforms like WeChat can reduce users’ feelings of loneliness and increase
their sense of well-being through emotional and social fulfilment, they may also result
in a psychological burden when expectations are not met. Gan et al. (2021) argued
that despite meeting particular social needs, excessive use may introduce behavioural
pressure. Similarly, Zhang (2023) noted that when users’ expectations of gratification
126

SEARCH 17(2), 2025
overloaded, social interaction becomes ritualised and emotionally exhausting, leading
to feelings of boredom and helplessness. As Zhou and Wang (2023) emphasised, users
experience well-being when their basic needs are met, but may suffer psychologically
when gratification is consistently frustrated.
Further, UGT also highlights users’ identity needs, which manifest in self-
presentation behaviours on social media platforms (Goffman, 2023). For example,
users often post content to manage impressions and maintain social connections with
friends, colleagues, and family members (Fan et al., 2021; Ji, 2021). While this supports
social interaction needs, it also introduces social pressure, where the number of likes and
comments may lead to fatigue. Teng et al. (2022) cautioned that the contradiction between
the desire for information and the reality of information overload contributes to cognitive
fatigue, decreasing continued use. This view is echoed by Li and Liu (2025), who noted
that users often use self-presentation and social engagement as a coping strategy.
Thus, while UGT emphasises that users turn to social media for gratification
across informational, emotional, and social domains, excessive or unfulfilled use may lead
to adverse effects such as social media fatigue. The theory thus provides a comprehensive
lens to understand both the appeal and the limitations of social media in users’ daily lives.
Social media fatigue: Causes and effects
Social media fatigue (SMF) typically manifests across emotional and behavioural
dimensions. Emotionally, it is associated with negative feelings such as tiredness, boredom,
indifference, and disinterest, which undermine users’ enjoyment of social platforms (Zhang
et al., 2021). These emotional symptoms can also manifest in behavioural outcomes, such
as reduced attention, forgetfulness, difficulty with decision-making, and impaired coping
abilities (Ream & Richardson, 1996). Teng et al. (2022) and Pang (2021) emphasised that
SMF results from emotional dysregulation, a state in which users are unable to manage
their emotions effectively over prolonged periods of social media use. This emotional
distress leads to diminished platform engagement, avoidance of interaction, and, in some
cases, a desire to withdraw from online spaces. However, complete disengagement may be
hindered by social obligations or pressure to remain connected (Li & Tang, 2022).
The formation of SMF has been examined at three interrelated levels: individual,
interpersonal, and environmental (McLeroy et al., 1988). On the individual level, emotional
dysregulation and lack of self-awareness can lead to an accumulation of negative emotions,
eventually manifesting as fatigue (Han, 2024; Tang, 2022). Zheng and Ling (2021)
noted that users with weak self-regulation are particularly vulnerable. Interpersonally,
the pressure to engage in social feedback activities—such as liking, commenting, and
maintaining online impressions—can become exhausting (Fan et al., 2021). Even users
with high self-efficacy may experience fatigue from high engagement demands. On the
environmental level, negative use behaviours such as compulsive checking and habitual
scrolling emerge as enthusiasm wanes (Fan et al., 2022), reflecting a passive relationship
with social media. As social platforms become increasingly embedded in daily routines,
fatigue accumulates, even as users struggle to disconnect.
One key driver of SMF at the environmental level is information overload. Yang
et al. (2021) as well as Wu and Li (2022) defined social media exhaustion as the result of
overwhelming information exposure during interactive use. In an increasingly networked
world, users struggle to process the vast amount of content presented, leading to stress,
127

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
low-quality engagement, and eventual fatigue. This aligns with Liu and He (2021), who
argued that redundant and low-value content heightens users’ emotional burden. As
users’ cognitive capacity lags behind the exponential growth of online information, the
overload negatively affects their performance, decision-making, and mental well-being
(Li & Zhou, 2024; Noor Azri et al., 2024; Tian et al., 2025). Bright et al. (2015) further
deconstructed this phenomenon into four contributing factors: social media confidence,
self-efficacy, privacy concerns, and perceived usefulness. These variables shape how users
tolerate social media interactions and ultimately influence their level of fatigue.
WeChat use among university students in China’s “GuanXi” society
In Chinese social context education, social harmony is achieved through a strict hierarchy
of parents and ancestors, collectivism, and respect for a nation and its leaders (Ilin et
al., 2024; Weiqi et al., 2023). This concept applies to elders, teachers, and higher-ranking
individuals (Koczkás, 2023). In today’s society, these values are reflected through GuanXi,
representing the status quo and maintaining relationships between people. In a collective
culture, social order is crucial, so individuals will do their best to save face and avoid
conflict (Wenzhong & Grove, 1999). Moreover, when giving feedback to teachers and
students in China, students passively accept teachers’ feedback without questioning
or asking for clarification. In the concept of social capital, bridging and bonding refer
to bonding and bridging social capital, respectively (Putnam, 2000). Compared to the
individual-centred social model in the West, Chinese university students’ WeChat social
networking is more influenced by social capital management (Li et al., 2021), focusing
on how to maintain old relationships (bonding) and expand new ones (bridging).
In today’s Chinese universities, WeChat is not only a communication tool but also
an important platform for university students to establish, maintain, and expand their
social networks. Liu et al. (2021), consistent with the findings of Li et al. (2021), argued
that university students’ use of WeChat is not only influenced by information needs, social
interaction needs, and identity management, but also moderated by specific sociocultural
factors.
Based on the literature and the research gaps identified in the studies mentioned
above, despite the fact that there have been studies that have explored the relationship
between UGT and social media fatigue, the following gaps remain. First, most studies
focus on a single need (e.g., information needs or social interactions) and ignore the
interaction between multiple needs. For example, the interplay between users pursuing
social interactions while reducing them due to the pressure of identity management has
not been studied in depth. Second, current research is less designed to explore and study
social media represented by WeChat, which is closely related to daily life and in the context
of Chinese interpersonal society. Therefore, the following research objective and research
question were formulated:
RO: To identify and categorise the different types of social media fatigue
experienced by university students in Liaoning Province based on their
daily WeChat usage patterns.
RQ: What common behavioural patterns are associated with social media
fatigue observed in students’ daily WeChat use?
128

SEARCH 17(2), 2025
METHODOLOGY
This research employed a qualitative approach, utilising diary studies, to investigate the
emotional and behavioural patterns associated with WeChat fatigue among university
students. The diary method enables in-depth, temporally grounded data collection,
providing access to participants’ daily emotional states (White, 2023; Schönbächler, 2023).
A semi-structured diary format was employed, with participants responding to guiding
questions over 14 days (Table 1). This structure helped reduce the burden while ensuring
data richness (Harris et al., 2021).
Participants were recruited through convenience sampling on the XiaoHongShu
(Red Note) platform, a popular platform among the target demographic. Location filters
and visible IP information were used to ensure participants were university students aged
19–24 in Liaoning Province. A total of 15 participants were selected, including both
undergraduate and postgraduate students, which falls within the recommended range
for phenomenological research (Creswell, 2013). In order to enhance the trustworthiness
of the study, measures such as consistent diary prompts, follow-up clarifications, and
detailed demographic reporting were implemented. The study emphasised credibility by
maintaining direct engagement with participants during the two weeks, and confirmability
was strengthened by retaining original quotes for thematic analysis. These strategies align
with established qualitative research quality criteria (Haq et al., 2023; Creswell, 2013),
which emphasise credibility, transferability, dependability. Specifically, maintaining
prolonged engagement and using participant quotes are commonly recommended to
ensure credibility and confirmability in qualitative inquiry (Creswell, 2013).
Table 1. Diary record form
Length and Frequency of Emotions and Feelings about Social Interactions in
Using WeChat Today Using WeChat Today WeChat Today
Day1
Day2
Day3
Day4
Day5
Day6
Day7
Day8
Day9
Day10
Day11
Day12
Day13
Day14
129

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
Table 2. Sample demographics
| S=Sample | Age  | Gender  | Education Status      | Grade       |
| -------- | ---- | ------- | --------------------- | ----------- |
| S1       | 23   | Female  | Master’s student      | Fist year   |
| S2       | 23   | Female  | Master’s student      | Second year |
| S3       | 22   | Female  | Undergraduate student | Fourth year |
| S4       | 20   | Male    | Undergraduate student | Third year  |
| S5       | 19   | Female  | Undergraduate student | Third year  |
| S6       | 21   | Male    | Undergraduate student | Second year |
| S7       | 21   | Female  | Undergraduate student | Fourth year |
| S8       | 20   | Male    | Undergraduate student | Second year |
| S9       | 24   | Male    | Master’s student      | Second year |
| S10      | 20   | Male    | Undergraduate student | Third year  |
| S11      | 21   | Male    | Undergraduate student | Fourth year |
| S12      | 22   | Female  | Undergraduate student | Fourth year |
| S13      | 22   | Female  | Master’s student      | Fist year   |
| S14      | 24   | Female  | Master’s student      | Second year |
| S15      | 20   | Female  | Undergraduate student | Second year |
RESULTS AND DISCUSSION
This study identified and classified four types of WeChat fatigue among university students
in Liaoning Province, based on their usage patterns. These include: information overload
(e.g., excessive content and response pressure), task-oriented use (communication tied
to academic or internship demands), privacy fatigue (concerns overexposure and social
judgment), and stage-based fatigue (temporary fatigue in specific contexts).
These  categories  were  derived  through  inductive  coding  and  repeated  theme
analysis, grounded in participants’ lived experiences. Together, they reflect how WeChat
use intersects with students’ academic, emotional, and social lives. While the types are
defined as separate, they often overlap in experience, for instance, task-orientated use
usually comes with information overload. This mix of influences leads to emotional and
behavioural fatigue, including anxiety, avoidance, withdrawal, or dissatisfaction. The
following sections elaborate on each type, using qualitative evidence to illustrate how
these forms of fatigue emerge, interact, and evolve across different user scenarios.
Information overload and WeChat fatigue
Information overload emerged as a core trigger of WeChat fatigue, particularly in high-
density group communication environments such as university classes, internship groups,
and administrative announcements. Participants reported that even with notification
settings adjusted (e.g., Do-Not-Disturb mode), certain system-level alerts, such as “@all”
mentions, penetrated these boundaries, creating a sense of loss of control. This persistent
exposure  to  unfiltered  task-related  information  not  only  heightened  participants’
emotional fatigue but also reinforced their sense of helplessness. For example, S5 (D7)
described an incident where message vibrations in the library disrupted both their focus
and the surrounding environment, leading to embarrassment and self-consciousness. This
suggests that WeChat fatigue is not merely a response to message volume, but also involves
130

SEARCH 17(2), 2025
the social context in which communication takes place and the individual’s perceived
obligation to manage interruptions respectfully. Over time, such repeated micro-stressors
can foster avoidance behaviours, such as minimising message responses, delaying replies,
or mentally withdrawing from social interactions altogether. This coping mechanism
preserves cognitive and emotional resources.
Day7: The most annoying thing about using WeChat today is that I was
studying in the library. The vibration of my mobile phone shook the table
too loudly, and for a Moment, it felt like the whole table was looking at me;
well! Embarrassed! Awkward! I was embarrassed and felt the impact of my
own not to say, but also affected this table to study the people. But there’s no
way for me to turn off the beep, and even though I’ve selected the message
no-disturb feature, after I give it the setting, there’s no way to turn it off
because of situations like @AllAssociates, it’s still coming back to bother
me... (Informant S5)
Further, information overload creates an information processing burden for
student users and is an important trigger for emotional fatigue. It is mainly reflected
in the following four aspects: firstly, the burden and interference of information
management; due to the huge amount of information and difficulty to completely shield,
users will be forced to receive a large amount of irrelevant information, resulting in an
increased psychological burden. Second, the bombardment of task-related information
exacerbates the psychological pressure, making users feel tired in their studies and work
and even resistant to using WeChat. Finally, the accumulation of repetitive information,
unnecessary social interactions, and resistance to social content caused users to suffer
from emotional fatigue when dealing with WeChat and even actively reduce their use to
lower their psychological burden. As expressed in S5’s diary on D6:
Day6:I blocked a group today but didn’t back out because it was a class group,
and I couldn’t back out. They have to swipe at the group with terriers’ recent
popularity; I don’t understand why. It makes me feel annoyed, repetitive
messages, constantly quoting the last person, quoting about 3 screens; I feel
annoyed when they swipe like that. Some of the important information is
topped off! (Informant S5)
Task-based use leads to usage behaviour fatigue
As WeChat became deeply embedded in academic and internship routines, participants
experienced a distinct form of behavioural fatigue driven by its task-oriented use. The
constant inflow of assignments, institutional instructions, and administrative demands,
often delivered via WeChat group chats, created a state of hyper-responsiveness and
chronic anxiety. Students described an overwhelming sense of obligation to remain
connected, fearing they might miss important instructions from tutors or superiors. This
fatigue is particularly prominent during periods of high task density, such as the start of
semesters, where compulsive checking and forced responsiveness undermine autonomy
and concentration.
131

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
Day 6: After the start of the school year, I feel like I haven’t had a break, and
I’ve been receiving and replying to all kinds of messages every day. Lately,
whenever I touch my mobile phone, turn on my computer, and hook up to
WeChat, I don’t feel much like checking WeChat. I especially don’t want to
reply to some chats and such. On the one hand, the chat box is a bit more.
On the other hand, the circle of friends, basically the same door or on the
classmates and such, which is not everyone else is on a roll, don’t want to see
those things... So miss the holidays; there’s no fatigue or negativity during the
holidays. (Informant S2)
Day14: Today, I took the train back to school. I had a little confused feeling,
worried about the future, and anxious in the brush about all kinds of messages.
I am looking for a friend to chat to relieve, but I am waiting for the message
reply. I can always see the message-free group of small red dots, clicked into
a look at 99, and I do not want to see it. I also do not want to point to the
small red dot. Because there’s this little red dot there, I feel like I have to
tap it and get that out of the way, and while I’m doing it, I just feel annoyed.
(Informant S14)
Moreover, students in managerial roles (e.g., S10) reported role strain due to their
responsibility in processing, forwarding, and responding to a large volume of administrative
content. This reflects a role conflict where the expectation to manage information clashes
with personal boundaries, contributing to long-term resistance and detachment toward
the platform. Task-based usage fatigue, therefore, is not only behavioural but relational
and emotional, shaped by institutional roles, perceived urgency, and interface design.
Day13: Today is the first day of school, and this term can be much easier.
When I think back to when I first wanted to enroll in school when I participated
in the student union and held the position of class president, I needed to add a
very large number of microblogging groups, and I needed to deal with a very
large amount of information every day. Especially at certain times, such as
the beginning of the school year and the end of the term, there will be a very
large number of messages that I need to deal with, whether it is forwarding
or replying, or teachers will come to me privately many messages need to be
communicated through WeChat. (Informant S13)
Social interaction needs and WeChat fatigue
In daily learning and social engagement, WeChat serves not only as a formal
communication tool but also as a dense site of social signalling, where users navigate
multiple roles under expectations of responsiveness, politeness, and visibility. In the user’s
social network, it is deeply involved, which puts them under varying levels of pressure
during the task reception, information management, and self-presentation processes.
With the accumulation of weak ties on WeChat, users face the constant need to maintain
boundary work between public and private personas, adjusting their behaviour to
conform to dynamic social expectations. On the one hand, the high-frequency
132

SEARCH 17(2), 2025
information flow and task assignment in group chats create a state of constant alertness,
pushing student users to oscillate between fear of missing out and information fatigue
(S4, D10).
Even private moments are psychologically occupied by the expectation of
digital immediacy, leading to cumulative emotional exhaustion. On the other hand,
WeChat Moments—as a core mechanism for personal image management—relies on
visible interaction metrics (likes and comments), which intensify social comparison
and performance anxiety. Although this encourages sharing behaviour, the absence of
expected feedback often triggers an emotional dissonance between effort and validation,
prompting withdrawal (S1, D3). Some users even reduced the frequency of sharing or
adopted more defensive strategies, such as ‘Visible for three days only’ or blocking specific
contacts, to protect themselves from social judgment or feelings of inadequacy.
Day10: I felt a bit awkward when I was using WeChat today. I didn’t look at
my phone much because I was a bit busy during the day and missed something
discussed in the mentor’s group. By the time I saw it, it was past this, not to
what to reply, awkward. (Informant S4)
Day3: Spit on work with a WeChat miniature because I felt so angry at my
internship today that I had to do it! ... (Informant S1)
Fatigue from social pressure is reflected in shifts in communication style and
avoidance behaviours. Faced with high-frequency messages and Guanxi-based social
demands, some users selectively disengage from conversations to conserve mental energy,
which suggests not only irritation but a strategic withdrawal from over-connectedness.
It is especially salient in professional or tutor-led group chats, where the expectation of
timely replies constructs a quasi-on-call status for student users. This unspoken ambient
pressure blurs the line between autonomy and obligation, amplifying emotional strain
(S15, D14). Additionally, during transitional identity phases (e.g., entering university
or the workforce), users reported adjusting their WeChat presence to fit new interaction
norms (S11, D1). Such identity recalibration often comes with increased self-monitoring
and higher social anxiety, further reducing the appeal of WeChat as a casual social
space. Over time, some users exhibit symptoms of social withdrawal, such as abandoning
homepage updates or reducing their use of WeChat altogether (S8, D6). This suggests
a more profound emotional fatigue stemming from unmet expectations for recognition,
social reciprocity, and self-worth preservation.
Day14: Another pile of assignments to write, and the tutor sent 5 reminders in
a row to the group. I was very apprehensive and anxious about not finishing and
doing it slowly, and I would have cried if I had been the last one in the group to
hand it in. Because he specified that he would come and private message me, I
was worried about seeing his message reminders and his replies.
(Informant S15)
133

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
Day1: Today, I have organized my friend circle’s content and set it to be visible
only for three days. Because I don’t want people who just added (WeChat), to
go through my previous movements from beginning to end. I don’t want myself
to be picked apart like that. (Informant S11)
Day6:I didn’t update my dynamics today. It’s been a long time since I did.
Because when I first went to university, I was more eager to show myself,
wanting to show a good side to everyone or looking for some same-frequency
people I felt I could attract. And kinda hoped that people would like it more,
but slowly I realized that not many people liked it, it was too embarrassing, so
now I don’t post much ...... (Informant S8)
In addition to posting behaviours, user fatigue also manifests in interpersonal
communication habits. Facing high-frequency group messages and complex Guanxi
obligations, some participants reported deliberately delaying or avoiding responses
to preserve mental energy. This selective withdrawal became more pronounced during
identity transition periods, such as entering university or the workplace, when users had
to recalibrate their online persona and social strategies to fit new norms. As emotional
fatigue accumulated, some opted for passive resistance—muting groups, ignoring
messages, or limiting app usage—indicating a shift from being socially available to being
strategically invisible.
Identity management and WeChat fatigue
With the expansion of social relationships among student users, their WeChat networks
increasingly consist of weak ties, such as classmates, distant acquaintances, or former
colleagues. This densification of semi-familiar connections amplifies users’ need to
manage their privacy boundaries and personal visibility carefully. Features like “Moments
visibility,” chat deletion, and blocking specific groups are not just technical functions
but have become tools of personal boundary regulation in response to rising social
complexity. Participants reported frequently adjusting the visibility of their Moments
depending on their mood, life events, or seasonal context. For example, S9 (D7) hid posts
during emotional lows to avoid scrutiny, and S3 (D8) limited the number of summer
photos from classmates upon returning to school. These adjustments reflect a dynamic
and context-dependent strategy of privacy calibration, in which users aim to minimise
unwanted exposure while maintaining a minimal level of self-expression.
Day7: Today, I set my friend circle settings back to one month visible. A few
days ago, is three days visible, because recently fell out of love, don’t want
to let co-friends or irrelevant eaters pick my dynamic to see, by the way, the
previous dynamic all deleted. (Informant S9)
Day8: Recently school started, I set my friend to revisit one month visible,
back to school. I don’t want others to see how wonderful I have spent this
summer holiday! So today, I adjusted the visible range of my circle of friends.
(Informant S3)
134

SEARCH 17(2), 2025
However, such flexibility comes at a psychological cost. The chronic need to
regulate visibility forces users to ask, “Who should see this repeatedly? What if the wrong
person sees it?” This leads to privacy fatigue—a condition in which the cognitive and
emotional effort to maintain contextual boundaries becomes overwhelming. The mental
load of this privacy curation reduces users’ motivation to share, not because of a lack of
content, but due to the exhausting anticipation of how others may interpret it. Moreover,
privacy management is similar to self-presentation strategies. On platforms like WeChat
Moments, users often attempt to construct an “ideal self” to gain validation and reinforce
their social identity. This identity construction involves not only selecting what to show
but also deliberately controlling timing, wording, and visual aesthetics.
Day12: Today, I posted a photo of going out to play; it’s been 3 hours, and
still, not many people like it. I feel quite good ah, the circle of friends ah
resonance or less (Informant S11)
When posts fail to generate expected feedback, users experience what can be
described as interactional dissonance—a mismatch between the effort invested in self-
presentation and the recognition received. This dissonance often leads to emotional
discomfort, post-deletion, self-censorship, or even withdrawal from the platform. For
instance, S12 (D11) hesitated to share a song she valued, fearing others would not
appreciate it. Meanwhile, this emotional vulnerability is amplified by upward social
comparison. Browsing peers’ Moments filled with job offers, academic accomplishments,
or curated life snapshots creates a distorted perception of others’ success, leading users
to feel inadequate or overwhelmed. S7 (D10), for example, described actively avoiding
WeChat Moments to escape these emotionally taxing comparisons.
Day10: Today’s study pressure is a bit big. I do not want to brush WeChat
Moment, am open to seeing the same door and classmates in the sun in the
offer, the sun published journals, too voluminous, do not want to see those
things... (Informant S7)
Day11: Today is not a suitable day to send friends circle no mood no photos
no copy three no products, only songs want to share, but surely no one listen,
so the pressure is not sent (Informant S12)
In such cases, the interactional dissonance is not only internal but socially
reinforced; users feel they must both perform and compete, and when they fall short of
imagined expectations, emotional fatigue sets in. Over time, this creates a vicious cycle of
reduced engagement, rising anxiety, and gradual withdrawal from public digital spaces.
SUMMARY OF RESULTS
While prior studies have discussed social media fatigue in broad terms, few have examined
how WeChat, which is the dominant social media platform in China, shapes users’ fatigue
experiences within specific cultural and academic contexts. This study identified and
135

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
classified the types of WeChat fatigue among university students in Liaoning Province
based on their WeChat usage patterns, and explored their formation mechanisms and
effects. Research has shown that WeChat fatigue manifests itself in the form of information
overload, task-oriented use, privacy fatigue, and stage fatigue, and these types interact
with each other to lead to emotional and behavioural fatigue.
Thus, the results of the study are parallel to the study of Whiting and Williams
(2013), Fan et al. (2021), and Metwally et al. (2025), which are consistent with UGT, the
theory that explains how individuals actively use media to fulfil specific needs. In the same
way, the interplay between these needs was also highlighted. Information overload is a
major trigger for emotional fatigue. The influx of overloaded information, the difficulty
of managing information, and the pressure to respond to group interactions can lead to
negative emotional reactions such as anxiety and avoidance. The results of the study are
aligned with the study of Tian et al. (2025), Gan et al. (2021), Zhou and Wang (2023), Fan
et al. (2021), Noor Azri et al. (2024).
Studies have shown that overloaded demand leads to emotional shifts in users. Next,
WeChat’s role as a task-oriented platform exacerbates usage fatigue. Many participants
reported staying online and responding quickly due to academic and internship work-
related communication. This social pressure corresponds to the need for social interaction
in UGT. The results of the study are equivalent to the study of Whiting and Williams
(2013) as well as Li et al. (2025); in UGT, users use the medium to not only obtain
information but also to satisfy social connections and maintain interpersonal needs. Users
feel burdened and fatigued when this need evolves into a passive response to obligations
or tasks. However, users will be unable to quit using WeChat due to social pressure; the
results of the study are parallel to the study of Li and Tang (2022), Teng et al. (2022), and
Pang (2021).
Finally, privacy fatigue mainly reflects users’ anxiety and powerlessness in WeChat
Moment, content publishing, and managing personal information. Student users
would repeatedly modify or delete relevant updates for fear of privacy leakage or social
evaluation. This is in line with the need for identity management in UGT. This finding
is similar to that of Goffman (2023), Pang (2021), Li and Liu (2025), and Gan et al.
(2024), where users who are dissatisfied with social media content presentation and those
satisfied with social media content presentation, display different levels of negative use
behaviours. This study explored the interactions between different types of social media
fatigue by incorporating UGT and also explored WeChat fatigue among university
students from a Chinese social context perspective.
CONCLUSION
This study drew on the Uses and Gratifications Theory and identified three main types
of WeChat fatigue among university students in Liaoning Province, China: information
overload, task-oriented use, privacy-related fatigue and stage-based fatigue. These forms
of fatigue ultimately contribute to both emotional and behavioural exhaustion. This
finding extends existing research by integrating the three core gratification needs from
UGT to further explain university students’ motivations for using WeChat and their
resulting fatigue experiences.
136

SEARCH 17(2), 2025
It also helped refine the theory’s applicability within the context of Chinese higher
education. At the practical level, educators can promote digital literacy based on these
findings to help students establish healthier boundaries for social media use. Meanwhile,
platform designers might consider optimising notification systems, enhancing privacy
controls, and implementing interface features that help alleviate user fatigue. Future
research could further investigate how different types of WeChat fatigue impact students
and explore targeted intervention strategies to reduce the negative effects on their mental
health.
Open Access: This article is distributed under the terms of the Creative Commons Attribution
License (CC-BY 4.0) which permits any use, distribution and reproduction in any medium, provided
the original author(s) and the source are credited.
References
Bhowmik, T. (2025). Endless scrolling through social media and work boredom: a dynamic spillover
of information overload. Organization Management Journal, 22(1), 38–47. https://doi.org/
10.1108/omj-06-2024-2225
Bright, L. F., Kleiser, S. B., & Grau, S. L. (2015). Too much Facebook? An exploratory examination
of social media fatigue. Computers in Human Behavior, 44, 148–155. https://doi.org/10.1016/j.
chb.2014.11.048
Cheng, Y. (2022). Application of use and gratification theory in new media research. Western Radio
and Television, 43(4), 44–46.
Creswell, J. W. (2013). Steps in conducting a scholarly mixed methods study. DigitalCommons@
University of Nebraska - Lincoln. https://digitalcommons.unl.edu/dberspeakers/48/
Fan, C., Deng, X., & Han, Y. (2022). Negative use behaviour of social media users: a multi-source
data fusion perspective. Library and Intelligence Work, 66(15), 76–85.
Fan, X., Jiang, X., Deng, N., Dong, X., & Lin, Y. (2021). Does role conflict influence discontinuous
usage intentions? Privacy concerns, social media fatigue and self-esteem. Information Technology
& People, 34(3),1152–1174. https://doi.org/10.1108/itp-08-2019-0416
Gan, C., Li, H., & Liu, Y. (2024). Understanding social media discontinuance behavior in China: A
perspective of social cognitive theory. Information Technology & People, 37(3),1185–1207.
Gan, C., Lin, L., & Xiao, C. (2021). An exploratory study of WeChat users’ intermittent dropout
behaviour from the perspective of rooting theory. Journal of Information Resources Management,
11(5), 96–102.
Goffman, E. (2023). The presentation of self in everyday life. In W. Longhofer & D. Winchester (eds),
Social theory re-wired (pp. 450–459). Routledge. https://doi.org/10.4324/9781003320609-59
Han, Y. (2024). Social media addiction, fatigue and the effects on young adults’ academic
performance in China. Quantum Journal of Social Sciences and Humanities, 5(5), 70–80.
https://doi.org/10.55197/qjssh.v5i5.428
Haq, Z. U., Rasheed, R., Rashid, A., & Akhter, S. (2023). Criteria for assessing and ensuring the
trustworthiness in qualitative research. International Journal of Business Reflections, 4(2), 150–
173.
Harris, A. L., Carmona, N. E., Moss, T. G., & Carney, C. E. (2021). Testing the contiguity of the sleep
and fatigue relationship: a daily diary study. Sleep, 44(5). https://doi.org/10.1093/sleep/zsaa252
Ilin, V., Ke, J., & Sunantana Nuanla-Or. (2024). Influence of culture on Chinese university students’
interaction with feedback. International Journal of Changes in Education.
Jabeen, F., Tandon, A., Sithipolvanichgul, J., Srivastava, S., & Dhir, A. (2023). Social media-
induced fear of missing out (FoMO) and social media fatigue: The role of narcissism,
comparison and disclosure. Journal of Business Research, 159, 113693. https://doi.org/10.1016/j.
jbusres.2023.113693
Ji, J. (2021). A new field of symbolic interaction: A study on WeChat user behavior patterns from the
perspective of Drama Theory. Audiovisual, 12, 166–167.
137

Exploring social media fatigue through WeChat Use: A diary study among university students in Liaoning, China
Koczkás, S. (2023). Confucianism: Ancient ideology or driving force of the future? A scoping r
eview on the effect of Confucian culture on innovation. Society and Economy, 45(4), 411–431.
https://doi.org/10.1556/204.2023.00021
Li, Q., & Tang, T. (2022). A study of social media fatigue behavior based on the theme model. Journal
of Hangzhou University of Electronic Science and Technology (Social Science Edition), 18(5),
54–59.
Li, S., Lei, T., & Cui, Z. (2021). Mechanisms and models of dropout behaviour of weakly relational
social media users in the perspective of subject-ego and object-ego theories. Modern Intelligence,
29(6), 52–59.
Li, X., & Zhou, X. (2024). A study of the relationship between problematic social media use, learning
fatigue, and self-career management. Advances in Psychology, 14, 322.
Li, Y., & Liu, R. (2025). How and when does enterprise social media usage threaten employees’
thriving at work? An affective perspective. Journal of Enterprise Information Management, 38(2),
704–742. https://doi.org/10.1108/jeim-08-2024-0466
Li, Y., Ren, L., Qiu, H., & Liu, H. (2025). How does generative AI relate to leisure satisfaction and
awareness? Leisure Sciences, 1–21. https://doi.org/10.1080/01490400.2025.2467966
Liu, H., Liu, W., Yoganathan, V., & Osburg, V.-S. (2021). COVID-19 information overload and
generation Z’s social media discontinuance intention during the pandemic lockdown. Technological
Forecasting and Social Change, 166(120600). https://doi.org/10.1016/j.techfore.2021.120600
Liu, Y., & He, J. (2021). “Why are you running away from social media?” Analysis of the factors
influencing social media fatigue: an empirical data study based on Chinese youth. Frontiers in
Psychology, 12, 674641. https://doi.org/10.3389/fpsyg.2021.674641
McLeroy, K. R., Bibeau, D., Steckler, A., & Glanz, K. (1988). An ecological perspective on health
promotion programs. Health Education Quarterly, 15(4), 351–377. https://doi.org/10.1177/
109019818801500401
Metwally, D., Bakari, H., & Manzoor, A. (2025). Social and psychological costs of problematic use of
social media: users and gratification perspective. Cogent Psychology, 12(1), 2467513. https://doi.or
g/10.1080/23311908.2025.2467513
Noor Azri, M. D., Abdull Malek, S. N. N., & Tuan Besar, T. B. H. (2024). An overview of information
overload, system feature overload, social overload and communication overload. Environment-
Behaviour Proceedings Journal, 9(SI19), 179–186. https://doi.org/10.21834/e-bpj.v9iSI19.5789
Ou, M., Zheng, H., Kim, H. K., & Chen, X. (2023). A meta-analysis of social media fatigue: Drivers
and a major consequence. Computers in Human Behavior, 140, 107597. https://doi.org/10.1016/j.
chb.2022.107597
Pang, H. (2021). How compulsive WeChat use and information overload affect social media fatigue
and well-being during the COVID-19 pandemic? A stressor-strain-outcome perspective.
Telematics and Informatics, 64, 101690. https://doi.org/10.1016/j.tele.2021.101690
Putnam, D. (2000). Bowling alone: The collapse and revival of American community. Simon and
Schuster.
Ream, E., & Richardson, A. (1996). Fatigue: A concept analysis. International Journal of Nursing
Studies, 33(5), 519–529.
Schönbächler, V. (2023). Instant messaging meets diary studies: Employing WhatsApp in audio diary
research with female journalists in Burkina Faso. Zeitschrift Für Qualitative Forschung, 24(1),
139–155. https://doi.org/10.3224/zqf.v24i1.11
Tang, X. (2022). Double overload, self-representation, and privacy dilemma: An analysis of the
drivers of social media fatigue. China Media Technology, 2022(74), 60–62.
Teng, L., Liu, D., & Luo, J. (2022). Explicating user negative behavior toward social media: an
exploratory examination based on stressor–strain–outcome model. Cognition, Technology &
Work, 24(1), 183–194. https://doi.org/10.1007/s10111-021-00665-0
Tian, Y., Chan, T. J., Liew, T. W., Chen, M. H., & Liu, H. N. (2025). Overwhelmed online:
investigating perceived overload effects on social media cognitive fatigue via stressor-strain-
outcome model. Library Hi Tech. https://doi.org/10.1108/lht-03-2024-0145
Weiqi, Y., Rahim, N. A., Yew Hoong, B. L., & Hassim, N. (2023). Sang culture: Exploring the new
Chinese youth movement and the way forward. SEARCH Journal of Media and Communication
Research, 15(3), 67–84.
138

SEARCH 17(2), 2025
Wenzhong, H., & Grove, C. L. (1999). Encountering the Chinese: A guide for Americans. The InterAct
Series. Intercultural Press.
White, L. (2023). My dear diaries: Following, valuing and reflecting on moments with research
materials. Qualitative Research, 23(3), 632–650. https://doi.org/10.1177/14687941211039409
Whiting, A., & Williams, D. (2013). Why people use social media: A uses and gratifications approach.
Qualitative Market Research, 16(4), 362–369. https://doi.org/10.1108/QMR-06-2013-0041
Wu, B., Li, F., Zhou, L., Liu, M., & Geng, F. (2022). Are mindful people less involved in online
trolling? A moderated mediation model of perceived social media fatigue and moral
disengagement. Aggressive Behavior, 48, 309–318. https://doi.org/10.1002/ab.22013
Wu, H.-X., & Li, H. (2022). Privacy protection in the era of social media from the perspective of
“Three Days of Visibility” in WeChat Moments. News Tide, 9, 51–53.
Yang, C., Holden, S. M., & Ariati, J. (2021). Social media and psychological well-being among youth:
The multidimensional model of social media use. Clinical Child and Family Psychology Review,
24(3), 631–650. https://doi.org/10.1007/s10567-021-00359-z
Zawawi, S. M. N. A., Bolong, J., Adzharuddin, N. A., & Kuppusamy, E. (2025). Exploring loneliness
and social media addiction: Key drivers of phubbing behaviour. SEARCH Journal of Media and
Communication Research, 17(5), 134–148.
Zhang, Q. (2023). Exploring the effects of overload and stress factors on WeChat moments users’
discontinuous usage intention: An SSO Perspective. SHS Web of Conferences, 155. https://doi.
org/10.1051/shsconf/202315502024
Zhang, S., Shen, Y., Xin, T., Sun, H., Wang, Y., Zhang, X., & Ren, S. (2021). The development and
validation of a social media fatigue scale: From a cognitive-behavioral-emotional perspective.
PLOS ONE, 16(1), e0245464. https://doi.org/10.1371/journal.pone.0245464
Zheng, H., & Ling, R. (2021). Drivers of social media fatigue: A systematic review. Telematics and
Informatics, 64, 101696. https://doi.org/10.1016/j.tele.2021.101696
Zhou, Y., & Wang, J. (2023). The effect of the frequency of social media posts on the subjective well-
being of young people: Mediating the satisfaction of basic psychological needs. Psychological
Science, 46(6), 1454. https://doi.org/10.16719/j.cnki.1671-6981.20230623
Jia Puxiu
is a PhD student at the School of Media & Communication (SOMAC), Faculty of
Social Science & Leisure Management, Taylor’s University. Her research focuses on
social media and audiences. Email: 0362521@sd.taylors.edu.my
Normaliza Abd. Rahim (Prof Dr)
is a Senior Research Fellow at Taylor’s University, Malaysia. Her expertise is in media
and technology, discourse studies, linguistics and educational technology. She has
published more than 10 books and nearly 200 articles in journals, chapter in books,
proceedings etc. She holds the copyright for more than 100 items from lyrics, stories,
music etc. She also has extensive teaching experience in South Korea and United
Kingdom.
Nur Haniz Mohd Nor (Dr)
is the PhD Programme Director from the School of Media and Communication,
Faculty of Social Sciences and Leisure Management, Taylor’s University. Her
research interest revolves from journalism, freedom of expression of netizens, political
and cultural issues.
139